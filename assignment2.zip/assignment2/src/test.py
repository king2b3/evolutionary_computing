a = ['a','b','c','d']

print(a)

a = ''.join(a)

print(a)